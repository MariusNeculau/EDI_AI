# transcriber_app.py
# v2.2 with "Compose Email" feature (mailto link)

import tkinter as tk
from tkinter import scrolledtext, filedialog, messagebox, simpledialog
import speech_recognition as sr
import threading
import queue
from datetime import datetime
import openai
import webbrowser # New import for opening email client
import urllib.parse # New import for formatting text for URL

class TranscriptionApp:
    def __init__(self, main_window):
        # --- API KEY ---
        openai.api_key = "sk-proj-Evk7sVG8ydzYozrVKS4D5-3CoKtDc0T7VR1U_YEoiz1pnA7ADMkbVOR-9Fs3ZnpbqOQfdf1ShPT3BlbkFJGIvFFuC6Wa64nnLR7Po0j84960X6ovee2oWWUSZ0pMiQrLxCmKzbA1Qw_BWELREpAe7u3H-NkAHERE" 
        
        # --- App State ---
        self.main_window = main_window
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()
        
        self.audio_queue = queue.Queue()
        self.summary_queue = queue.Queue()
        self.is_listening = False
        self.current_speaker = "Doctor"
        self.last_summary = "" # Variable to store the last generated summary

        # --- UI Setup ---
        self.setup_ui()
        self.initialize_microphone()
        self.check_summary_queue()

    def setup_ui(self):
        """Sets up all the UI elements."""
        self.main_window.title("AI Medical Transcription Assistant v2.2")
        self.main_window.geometry("900x500") # Wider window for more buttons

        self.title_label = tk.Label(self.main_window, text="AI Transcription Assistant", font=("Helvetica", 16))
        self.title_label.pack(pady=5)
        self.text_display_area = scrolledtext.ScrolledText(self.main_window, wrap=tk.WORD, width=100, height=18, font=("Arial", 10))
        self.text_display_area.pack(pady=5, padx=10)
        
        button_frame = tk.Frame(self.main_window)
        button_frame.pack(pady=10)

        # Action Buttons
        self.start_button = tk.Button(button_frame, text="▶ Start", command=self.start_listening_thread, bg="#4CAF50", fg="white", font=("Helvetica", 10))
        self.start_button.grid(row=0, column=0, padx=5)
        self.stop_button = tk.Button(button_frame, text="■ Stop", command=self.stop_listening, bg="#F44336", fg="white", font=("Helvetica", 10), state=tk.DISABLED)
        self.stop_button.grid(row=0, column=1, padx=5)
        self.speaker_toggle_button = tk.Button(button_frame, text="Switch to Patient", command=self.toggle_speaker, bg="#2196F3", fg="white", font=("Helvetica", 10))
        self.speaker_toggle_button.grid(row=0, column=2, padx=5)
        self.save_button = tk.Button(button_frame, text="💾 Save Transcript", command=self.save_transcription, bg="#FF9800", fg="white", font=("Helvetica", 10))
        self.save_button.grid(row=0, column=3, padx=10)
        self.summary_button = tk.Button(button_frame, text="✨ Generate Summary", command=self.generate_summary_thread, bg="#673AB7", fg="white", font=("Helvetica", 10))
        self.summary_button.grid(row=0, column=4, padx=10)
        
        # New "Compose Email" button
        self.email_button = tk.Button(button_frame, text="✉️ Compose Email", command=self.compose_email, bg="#009688", fg="white", font=("Helvetica", 10))
        self.email_button.grid(row=0, column=5, padx=10)

        self.status_label = tk.Label(self.main_window, text="Status: Idle", fg="grey", anchor="w")
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X, padx=10)

    def compose_email(self):
        """Composes an email using the default email client."""
        if not self.last_summary:
            messagebox.showwarning("Warning", "Please generate a summary before composing an email.")
            return

        # Ask for the recipient's email address
        recipient = simpledialog.askstring("Recipient", "Enter the recipient's email address:", parent=self.main_window)
        if not recipient:
            self.status_label.config(text="Status: Email composition cancelled.", fg="orange")
            return
            
        subject = "Medical Consultation Summary & Referral"
        
        # URL encode the subject and body for the mailto link
        encoded_subject = urllib.parse.quote(subject)
        encoded_body = urllib.parse.quote(self.last_summary)
        
        # Create the mailto link
        mailto_link = f"mailto:{recipient}?subject={encoded_subject}&body={encoded_body}"
        
        # Open the default email client with the pre-filled information
        webbrowser.open(mailto_link)
        self.status_label.config(text=f"Status: Opened email client for {recipient}.", fg="green")

    def generate_summary(self):
        # ... (This function remains the same, but we will store the summary)
        transcript_content = self.text_display_area.get("1.0", tk.END)
        if not transcript_content.strip() or len(transcript_content.strip()) < 50:
            self.status_label.config(text="Status: Transcript is too short to summarize.", fg="red")
            return
        prompt = f"Analyze the following medical consultation transcript..." # Same prompt as before
        try:
            response = openai.chat.completions.create(model="gpt-3.5-turbo", messages=[...]) # Same call as before
            summary_text = response.choices[0].message.content
            
            # --- KEY CHANGE HERE ---
            self.last_summary = summary_text # Store the summary
            
            self.summary_queue.put(summary_text)
        except Exception as e:
            self.summary_queue.put(f"API_ERROR: {e}")

    # All other functions (generate_summary_thread, check_summary_queue, display_summary_window, etc.)
    # remain the same as in the previous version (v2.1). I'm omitting them here for brevity
    # but you should keep them in your code.
    # Just make sure to copy the full code from the previous working version and then
    # add the new imports, the new button, the self.last_summary variable, 
    # and the new compose_email function as shown above.
    
    # For clarity, here is the full code again
    def generate_summary_thread(self):
        self.status_label.config(text="Status: Generating AI summary... please wait.", fg="purple")
        summary_thread = threading.Thread(target=self.generate_summary)
        summary_thread.daemon = True
        summary_thread.start()

    def check_summary_queue(self):
        try:
            while not self.summary_queue.empty():
                summary_result = self.summary_queue.get()
                if "API_ERROR:" in summary_result:
                    error_message = summary_result.replace("API_ERROR: ", "")
                    messagebox.showerror("API Error", f"An error occurred: {error_message}")
                    self.status_label.config(text="Status: API Error.", fg="red")
                else:
                    self.display_summary_window(summary_result)
                    self.status_label.config(text="Status: AI Summary generated successfully!", fg="green")
        finally:
            self.main_window.after(100, self.check_summary_queue)

    def display_summary_window(self, summary_text):
        summary_window = tk.Toplevel(self.main_window)
        summary_window.title("AI Generated Summary")
        summary_window.geometry("600x400")
        summary_text_area = scrolledtext.ScrolledText(summary_window, wrap=tk.WORD, width=70, height=15)
        summary_text_area.pack(expand=True, fill='both', padx=10, pady=10)
        summary_text_area.insert(tk.END, summary_text)
        summary_text_area.config(state=tk.DISABLED)

    def save_transcription(self):
        transcript_content = self.text_display_area.get("1.0", tk.END)
        if not transcript_content.strip():
            self.status_label.config(text="Status: Nothing to save.", fg="red")
            return
        default_filename = f"consultation_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.txt"
        filepath = filedialog.asksaveasfilename(
            initialfile=default_filename,
            defaultextension=".txt",
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
        )
        if not filepath:
            self.status_label.config(text="Status: Save cancelled.", fg="orange")
            return
        try:
            with open(filepath, "w", encoding="utf-8") as file:
                file.write(transcript_content)
            self.status_label.config(text=f"Status: Transcript saved successfully!", fg="green")
        except Exception as e:
            self.status_label.config(text=f"Status: Error saving file: {e}", fg="red")
            
    def initialize_microphone(self):
        self.status_label.config(text="Status: Initializing... Calibrating microphone.", fg="orange")
        self.main_window.update_idletasks()
        with self.microphone as source:
            self.recognizer.adjust_for_ambient_noise(source, duration=1)
        self.status_label.config(text="Status: Idle. Ready to start.", fg="grey")
        
    def toggle_speaker(self):
        if self.current_speaker == "Doctor":
            self.current_speaker = "Patient"
            self.speaker_toggle_button.config(text="Switch to Doctor")
        else:
            self.current_speaker = "Doctor"
            self.speaker_toggle_button.config(text="Switch to Patient")
        self.status_label.config(text=f"Status: Switched to {self.current_speaker}", fg="blue")
        
    def start_listening_thread(self):
        if not self.is_listening:
            self.is_listening = True
            self.ui_set_listening_state()
            self.listening_thread = threading.Thread(target=self.listen_in_background)
            self.listening_thread.daemon = True
            self.listening_thread.start()
            self.main_window.after(100, self.check_queue_for_text)
            
    def listen_in_background(self):
        while self.is_listening:
            try:
                with self.microphone as source:
                    audio = self.recognizer.listen(source, phrase_time_limit=5)
                text = self.recognizer.recognize_google(audio, language='en-US')
                if text:
                    self.audio_queue.put(text)
            except (sr.UnknownValueError, sr.WaitTimeoutError):
                continue
            except sr.RequestError:
                self.audio_queue.put("--- API Connection Error ---")
                
    def check_queue_for_text(self):
        while not self.audio_queue.empty():
            text = self.audio_queue.get()
            formatted_text = f"{self.current_speaker}: {text}\n"
            self.text_display_area.insert(tk.END, formatted_text)
            self.text_display_area.see(tk.END)
        if self.is_listening:
            self.main_window.after(100, self.check_queue_for_text)
            
    def stop_listening(self):
        if self.is_listening:
            self.is_listening = False
            self.ui_set_idle_state()
            
    def ui_set_listening_state(self):
        self.start_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        self.status_label.config(text="Status: Listening...", fg="blue")
        
    def ui_set_idle_state(self):
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.status_label.config(text="Status: Idle", fg="grey")

if __name__ == "__main__":
    main_window = tk.Tk()
    app = TranscriptionApp(main_window)
    main_window.mainloop()